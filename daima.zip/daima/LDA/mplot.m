data1=[6,0.28970832;
    7,0.25973582;
    9,0.36928648];
data2=[4,0.51415384;14,0.4129165];
data3=[6,0.9278775];
data4=[2,0.16583113;
    4,0.06562563;
    11,0.122836635;
    12,0.053150058;
    13,0.054107867;
    14,0.5071738];
data5=[0,0.031253252;
    1,0.031253252;
    2,0.5312012;
    3,0.031253252;
    4,0.031253252;
    5,0.031253252;
    6,0.03125328;
    7,0.031253252;
    8,0.031253252;
    9,0.031253252;
    10,0.031253252;
    11,0.031253252;
    12,0.031253252;
    13,0.031253252;
    14,0.031253252;
    15,0.031253252];
%% 
close all
figure('Color','white')
bar(data1(:,end));
set(gca,'Xticklabel',{'主题6','主题7','主题9'});
title('段落312','FontSize',18)
saveas(gcf,'312bar.jpg');
figure('Color','white')
pie(data1(:,end)./sum(data1(:,end)));
legend('主题6','主题7','主题9');
title('段落312','FontSize',18)
saveas(gcf,'312pie.jpg');

figure('Color','white')
bar(data2(:,end));
set(gca,'Xticklabel',{'主题4','主题14'});
title('段落313','FontSize',18)
saveas(gcf,'313bar.jpg');
figure('Color','white')
pie(data2(:,end)./sum(data2(:,end)));
legend('主题4','主题14');
title('段落313','FontSize',18)
saveas(gcf,'313pie.jpg');

figure('Color','white')
bar(data3(:,end));
set(gca,'Xticklabel',{'主题6'});
title('段落314','FontSize',18)
saveas(gcf,'314bar.jpg');
figure('Color','white')
pie(data3(:,end)./sum(data3(:,end)));
legend('主题6');
title('段落314','FontSize',18)
saveas(gcf,'314pie.jpg');

figure('Color','white')
bar(data4(:,end));
set(gca,'Xticklabel',{'主题2','主题4','主题11','主题12','主题13','主题14'});
title('段落315','FontSize',18)
saveas(gcf,'315bar.jpg');
figure('Color','white')
pie(data4(:,end)./sum(data4(:,end)));
legend('主题2','主题4','主题11','主题12','主题13','主题14');
title('段落315','FontSize',18)
saveas(gcf,'315pie.jpg');

figure('Color','white')
bar(0:15,data5(:,end));
%xlim([0,15]);
%set(gca,'Xticklabel',{'主题0','主题1','主题2','主题3','主题4','主题5','主题6','主题7','主题8','主题9','主题10','主题11','主题12','主题13','主题14','主题15'});
title('段落316','FontSize',18)
saveas(gcf,'316bar.jpg');
figure('Color','white')
pie(data5(:,end)./sum(data5(:,end)));
legend('主题0','主题1','主题2','主题3','主题4','主题5','主题6','主题7','主题8','主题9','主题10','主题11','主题12','主题13','主题14','主题15');
title('段落316','FontSize',18)
saveas(gcf,'316pie.jpg');



